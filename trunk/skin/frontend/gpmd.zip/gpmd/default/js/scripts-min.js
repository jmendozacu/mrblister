/**
 *
 * This file is part of the GPMD Magento Responsive Theme.
 *
 * The GPMD Magento Responsive Theme is free software: you can redistribute
 * it and/or modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * The GPMD Magento Responsive Theme is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with the GPMD Magento Responsive Theme. If not, see
 * http://www.gnu.org/licenses/.
 *
 * @category    GPMD
 * @package     GPMD_Responsive_Theme
 * @copyright   Copyright (c) 2012 GPMD.
 * @author      Matt Bailey @GPMD LTD
 */jQuery.noConflict();jQuery(document).ready(function(e){e(".messages").delay(5e3).fadeOut()});